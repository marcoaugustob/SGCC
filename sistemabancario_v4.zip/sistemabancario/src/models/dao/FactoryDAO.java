package models.dao;

import models.entity.CartaoCredito;
import models.entity.Cliente;
import models.entity.Transacao;

public class FactoryDAO {

	public IDAO<Cliente> createClienteDAO(){
		return new ClienteDAO();
	}
	
	public IDAO<CartaoCredito> createCartaoCredito(){
		return new CartaoCreditoDAO();
	}
	
	public IDAO<Transacao> createTransacao(){
		return new TransacaoDAO();
	}
}
