package models.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import models.entity.CartaoCredito;
import models.entity.Cliente;
import models.entity.Context;

public class ClienteDAO implements IDAO<Cliente>{
	
	EntityManager entityManager = Context.getInstance().createEntityManager();

	public void salvar(Cliente t) {
		
		entityManager.getTransaction().begin();
		entityManager.persist(t);
		entityManager.getTransaction().commit();
		entityManager.close();
	}

	public List<Cliente> listar() {
		entityManager.getTransaction().begin();
		Query query = entityManager.createQuery("FROM Cliente c");
		entityManager.close();
		try{
			return query.getResultList();
		}catch(NoResultException e){
			return null;
		}	
		
	}

	public Cliente remove(Cliente t) {
		entityManager.getTransaction().begin();
		entityManager.remove(entityManager.merge(t));
		entityManager.getTransaction().commit();
		entityManager.close();
		return t;
	}

	public Cliente update(Cliente t) {
		// TODO Auto-generated method stub
		return null;
	}

	public Cliente getById(int id) {
		// TODO Auto-generated method stub
		return null; 
	}
	
	public Cliente getByCpf(String cpf) {
		entityManager.getTransaction().begin();
		Query query = entityManager.createQuery("FROM Cliente c WHERE c.cpf=:p1");
		query.setParameter("p1", cpf);
		entityManager.close();
		try{
			return (Cliente) query.getSingleResult();
		}catch(NoResultException e){
			return null;
		}
	}
	
	public List<CartaoCredito> listarCartoes(Cliente cliente){
		entityManager.getTransaction().begin();
		Query query = entityManager.createQuery("FROM CartaoCredito cc WHERE cc.cliente=:cliente");
		query.setParameter("cliente", cliente);
		entityManager.close();
		try{
			return query.getResultList();
		}catch(NoResultException e){
			return null;
		}
	}
}
