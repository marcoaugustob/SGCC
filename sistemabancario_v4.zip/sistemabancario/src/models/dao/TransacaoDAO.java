package models.dao;

import java.util.List;

import models.entity.Transacao;

public class TransacaoDAO implements IDAO<Transacao>{

	
	public void salvar(Transacao t) {
		// TODO Auto-generated method stub
		
	}

	
	public List<Transacao> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	
	public Transacao remove(Transacao t) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public Transacao update(Transacao t) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public Transacao getById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
