package models.dao;

import java.util.List;

import models.entity.CartaoCredito;

public class CartaoCreditoDAO implements IDAO<CartaoCredito>{

	
	public void salvar(CartaoCredito t) {
		// TODO Auto-generated method stub
		
	}

	
	public List<CartaoCredito> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	
	public CartaoCredito remove(CartaoCredito t) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public CartaoCredito update(CartaoCredito t) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public CartaoCredito getById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
