package models.dao;

import java.util.List;

public interface IDAO<T> {

	public void salvar(T t);
	public List<T> listar();
	public T remove(T t);
	public T update(T t);
	public T getById(int id);
	
}
