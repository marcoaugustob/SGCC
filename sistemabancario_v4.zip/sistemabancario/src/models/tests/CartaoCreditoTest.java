package models.tests;

import java.util.List;

import junit.framework.Assert;
import models.business.BusinessCartaoCredito;
import models.business.BusinessException;
import models.entity.CartaoCredito;

public class CartaoCreditoTest {

	public void salvar() {
		CartaoCredito cc = new CartaoCredito();
		
		BusinessCartaoCredito businessCartaoCredito = new BusinessCartaoCredito();
		
		//try {
			//businessCartaoCredito.salvar(cc);			
		//}catch(BusinessException e) {
			//e.getMessage();
		//}
		
		Assert.assertEquals(true, cc.getId() > 0);
		
	}
	
	public void listar() {
		//List<CartaoCredito> listaCC = new BusinessCartaoCredito().listar();
		
		//Assert.assertEquals(true, listaCC.size() > 0);
	}
	
}
