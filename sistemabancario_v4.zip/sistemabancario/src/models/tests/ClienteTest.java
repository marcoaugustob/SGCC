package models.tests;

import java.util.List;

import org.junit.Test;

import junit.framework.Assert;
import models.business.BusinessCliente;
import models.business.BusinessException;
import models.dao.ClienteDAO;
import models.entity.Cliente;

public class ClienteTest {

	@Test
	public void salvar() {
		
		Cliente c = new Cliente();
		c.setCpf("18091");
		
		BusinessCliente businessCliente = new BusinessCliente();
		
		try {
		businessCliente.salvar(c);
		}catch(BusinessException e) {
			e.getMessage();
		}
		
		Assert.assertEquals(true, c.getId() != 0);
	}
	
	@Test
	public void  listarCliente() {
		List<Cliente> clientes = new BusinessCliente().ListarClientes();
		
		Assert.assertEquals(true, clientes.size() > 0);
	}
}
