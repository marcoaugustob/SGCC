package models.business;

public class BusinessException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BusinessException(String erroMessage) {
		super(erroMessage);
	}

}
