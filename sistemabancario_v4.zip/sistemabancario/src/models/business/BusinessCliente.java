package models.business;

import java.util.List;

import models.dao.ClienteDAO;
import models.entity.CartaoCredito;
import models.entity.Cliente;

public class BusinessCliente {

	

	/**
	 * Realiza o cadastro de um cliente.
	 * @param cliente - cliente a ser cadastrado
	 * @return - cliente cadastrado
	 * @throws Exception - n�o � poss�vel cadastrar dois clientes com o mesmo cpf
	 */
	public Cliente salvar(Cliente cliente) throws BusinessException{

		if(ConsultarCliente(cliente.getCpf())!=null)
			throw new BusinessException("CPF j� cadastrado!");
		else{
			new ClienteDAO().salvar(cliente);;
			return cliente;
		}
		
	}
	
	/**
	 * Consulta cliente cadastrado pelo cpf
	 * @param cpf
	 * @return
	 */
	public Cliente ConsultarCliente(String cpf){
		return new ClienteDAO().getByCpf(cpf);
	}
	
	/**
	 * Lista clientes cadastrados
	 * @return
	 */
	public List<Cliente> ListarClientes(){
		
		return new ClienteDAO().listar();
	}
	
	/**
	 * Remove o cliente passado por parametro
	 * @param cliente
	 * @throws Exception - n�o � possivel remover um cliente com cart�es validos
	 */
	public Cliente RemoverCliente(Cliente cliente) throws Exception{
		List<CartaoCredito> lista = ConsultarCartaoCredito(cliente);
		if(!lista.isEmpty())
			throw new Exception("Cliente ainda possui cart�es validos!");
		else{
			new ClienteDAO().remove(cliente);
			return cliente;
		}
	}
	public List<CartaoCredito> ConsultarCartaoCredito(Cliente cliente){
		return new ClienteDAO().listarCartoes(cliente);
		
	}
	
	
}
