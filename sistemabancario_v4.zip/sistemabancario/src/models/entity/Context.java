package models.entity;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Context {

	static EntityManagerFactory entityManager = Persistence.createEntityManagerFactory("sistemabancario");
	
	public static EntityManagerFactory getInstance() {
		return entityManager;
	}
	
}
